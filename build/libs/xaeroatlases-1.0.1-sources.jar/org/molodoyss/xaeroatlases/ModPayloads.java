package org.molodoyss.xaeroatlases;

import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import org.molodoyss.xaeroatlases.payload.ClientboundRDBGameruleValuePacket;

public class ModPayloads {
    public static void register() {
        PayloadTypeRegistry.clientboundPlay().register(ClientboundRDBGameruleValuePacket.TYPE, ClientboundRDBGameruleValuePacket.CODEC);
    }
}
