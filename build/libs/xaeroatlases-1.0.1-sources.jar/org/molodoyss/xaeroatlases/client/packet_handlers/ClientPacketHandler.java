package org.molodoyss.xaeroatlases.client.packet_handlers;

import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import org.molodoyss.xaeroatlases.Xaeroatlases;
import org.molodoyss.xaeroatlases.client.XaeroatlasesClient;
import org.molodoyss.xaeroatlases.payload.ClientboundRDBGameruleValuePacket;

public class ClientPacketHandler {
    public static void handleAll() {
        ClientPlayNetworking.registerGlobalReceiver(ClientboundRDBGameruleValuePacket.TYPE, ClientPacketHandler::handleReducedDebugInfoGetter);
    }

    public static void handleReducedDebugInfoGetter(ClientboundRDBGameruleValuePacket payload, ClientPlayNetworking.Context context) {
        XaeroatlasesClient.setIsReducedDebugInfo(payload.value());
        Xaeroatlases.LOGGER.info("updated value of gamerule 'reduced_debug_info'!");
    }
}
