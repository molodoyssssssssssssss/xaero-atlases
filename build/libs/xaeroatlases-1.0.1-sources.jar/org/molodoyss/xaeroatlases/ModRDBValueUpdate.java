package org.molodoyss.xaeroatlases;

import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.world.level.gamerules.GameRules;
import org.molodoyss.xaeroatlases.payload.ClientboundRDBGameruleValuePacket;

public class ModRDBValueUpdate {
    public static void init() {
        ServerPlayerEvents.JOIN.register(player -> {
            ClientboundRDBGameruleValuePacket packet = new ClientboundRDBGameruleValuePacket(player.level().getServer().getGameRules().get(GameRules.REDUCED_DEBUG_INFO));
            ServerPlayNetworking.send(player, packet);
        });
        ServerPlayerEvents.AFTER_RESPAWN.register((oldPlayer, newPlayer, alive) -> {
            ClientboundRDBGameruleValuePacket packet = new ClientboundRDBGameruleValuePacket(newPlayer.level().getServer().getGameRules().get(GameRules.REDUCED_DEBUG_INFO));
            ServerPlayNetworking.send(newPlayer, packet);
        });
    }
}
